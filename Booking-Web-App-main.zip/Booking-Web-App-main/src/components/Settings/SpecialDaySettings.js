import React from "react"

const SpecialDaySettings = () => {
  return <div>SpecialDaySettings</div>
}

export default SpecialDaySettings

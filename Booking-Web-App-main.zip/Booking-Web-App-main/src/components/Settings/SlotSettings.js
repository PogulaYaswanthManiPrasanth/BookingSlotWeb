import React from "react"

const SlotSettings = () => {
  return <div>SlotSettings</div>
}

export default SlotSettings
